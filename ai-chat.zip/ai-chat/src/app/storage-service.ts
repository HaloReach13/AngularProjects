import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  private readonly USERNAME_KEY = 'username';
  private readonly APIKEY_KEY = 'apiKey';

  setCredentials(username: string, apiKey: string) {
    window.localStorage.setItem(this.USERNAME_KEY, username);
    window.localStorage.setItem(this.APIKEY_KEY, apiKey);
  }

  username() {
    return window.localStorage.getItem(this.USERNAME_KEY);
  }

  apiKey(): string {
    return window.localStorage.getItem(this.APIKEY_KEY)  || '';
  }
}
