import { Component } from '@angular/core';
import { Joke } from '../models';
import { JokeService } from '../joke-service';
import { FormsModule } from '@angular/forms';
import { JokeItem } from '../joke-item/joke-item';

@Component({
  selector: 'app-joke-list',
  imports: [FormsModule, JokeItem],
  templateUrl: './joke-list.html',
  styleUrl: './joke-list.css',
})
export class JokeList {
  jokes: Joke[] = [];
  totalVotes = 0;
  totalLikes = 0;
  totalDislikes = 0;

  constructor(private jokeService: JokeService) {}

  ngOnInit() {
    this.jokeService.jokes$.subscribe(jokes => {
      this.jokes = jokes;
      this.calculateStats();
    });
  }

  calculateStats() {
    this.totalLikes = this.jokes.reduce((sum, joke) => sum + joke.likes, 0);
    this.totalDislikes = this.jokes.reduce((sum, joke) => sum + joke.dislikes, 0);
    this.totalVotes = this.totalLikes + this.totalDislikes;
  }
}
