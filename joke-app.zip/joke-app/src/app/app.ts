import { Component, signal } from '@angular/core';
import { JokeForm } from './joke-form/joke-form';
import { JokeList } from './joke-list/joke-list';


@Component({
  selector: 'app-root',
  imports: [JokeForm, JokeList],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('joke-app');
}
