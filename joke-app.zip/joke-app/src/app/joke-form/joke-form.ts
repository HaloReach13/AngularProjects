import { Component } from '@angular/core';
import { JokeService } from '../joke-service';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-joke-form',
  imports: [FormsModule],
  templateUrl: './joke-form.html',
  styleUrl: './joke-form.css',
})
export class JokeForm {
  username: string = '';
  jokeText: string = '';

  constructor(private jokeService: JokeService) {}

  onSubmit() {
    if (this.username && this.jokeText) {
      this.jokeService.addJoke(this.username, this.jokeText);
      this.username = '';
      this.jokeText = '';
    }
  }
}
