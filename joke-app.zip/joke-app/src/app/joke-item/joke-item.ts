import { Component, Input } from '@angular/core';
import { JokeService } from '../joke-service';
import { Joke } from '../models';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-joke-item',
  imports: [FormsModule, CommonModule],
  templateUrl: './joke-item.html',
  styleUrl: './joke-item.css',
})
export class JokeItem {
  @Input() joke!: Joke;

  constructor(private jokeService: JokeService) {}

  get score(): number {
    return this.joke.likes - this.joke.dislikes;
  }

  vote(type: 'like' | 'dislike') {
    this.jokeService.vote(this.joke.id, type);
  }
}
