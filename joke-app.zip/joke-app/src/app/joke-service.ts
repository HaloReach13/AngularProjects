import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Joke } from './models';

@Injectable({
  providedIn: 'root',
})
export class JokeService {
  private initialJokes: Joke[] = [];

  private jokesSubject = new BehaviorSubject<Joke[]>(this.initialJokes);
  jokes$ = this.jokesSubject.asObservable();

  addJoke(username: string, text: string) {
    const newJoke: Joke = {
      id: Date.now(),
      username: username,
      text: text,
      likes: 0,
      dislikes: 0
    };
    const currentJokes = this.jokesSubject.value;
    this.jokesSubject.next([newJoke, ...currentJokes]);
  }

  vote(jokeId: number, type: 'like' | 'dislike') {
    const currentJokes = this.jokesSubject.value.map(joke => {
      if (joke.id === jokeId) {
        return {
          ...joke,
          likes: type === 'like' ? joke.likes + 1 : joke.likes,
          dislikes: type === 'dislike' ? joke.dislikes + 1 : joke.dislikes
        };
      }
      return joke;
    });
    this.jokesSubject.next(currentJokes);
  }
}
